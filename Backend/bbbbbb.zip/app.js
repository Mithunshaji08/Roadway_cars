const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const User = require('./Model/User');

const app = express();
const PORT = 8055;

// Connect to MongoDB
mongoose.connect('mongodb+srv://mithunshaji2003:mithun@cluster0.veqjltb.mongodb.net/Roadway?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// Middleware
app.use(cors()); // Use cors middleware to enable CORS
app.use(bodyParser.json());

// Signup route
app.post('/signup', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // Check if the email is already registered
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    // Create a new user with the provided role
    const newUser = new User({ name, email, password, role });

    // Save the user to the database
    await newUser.save();

    res.status(201).json({ message: 'Signup successful' });
  } catch (error) {
    console.error('Error in signup:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// login
app.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Find the user by email and role
    const user = await User.findOne({ email, role });

    // If the user is not found, return an error
    if (!user) {
      return res.status(401).json({ error: 'Invalid email, role, or password' });
    }

    // Compare the provided password with the stored hashed password
    if (password !== user.password) {
      return res.status(401).json({ error: 'Invalid email, role, or password' });
    }

    // At this point, the login is successful
    res.status(200).json({ message: 'Login successful', user });
  } catch (error) {
    console.error('Error in login:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Fetch user details by ID
app.get('/user-details/:id', async (req, res) => {
  try {
    const userId = req.params.id;

    // Check if the provided ID is valid
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ error: 'Invalid user ID' });
    }

    // Find the user by ID
    const user = await User.findById(userId);

    // If the user is not found, return an error
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Return the user details
    res.status(200).json(user);
  } catch (error) {
    console.error('Error fetching user details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
